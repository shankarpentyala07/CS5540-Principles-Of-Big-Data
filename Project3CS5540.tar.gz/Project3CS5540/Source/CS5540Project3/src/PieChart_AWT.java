import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import javax.swing.JPanel;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.category.CategoryDataset;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.data.general.DefaultPieDataset;
import org.jfree.data.general.PieDataset;
import org.jfree.ui.ApplicationFrame;
import org.jfree.ui.RefineryUtilities;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
 
public class PieChart_AWT extends ApplicationFrame {
	
	static String currenttitle;
   
   public PieChart_AWT( String title ) {
      super( title ); 
      setContentPane(createDemoPanel( ));
   }
   
   private static PieDataset createDataset( ) {
      DefaultPieDataset dataset = new DefaultPieDataset( );
      InputStream in;
      BufferedReader reader;
      JSONParser jp = new JSONParser();
      String s1;
      JSONObject jo;
	try {
		
		if(currenttitle.contentEquals("Trending Hash Tags"))
		{
		File index = new File("/home/shankar/Desktop/trends_task2/hashtags");
		if (index.exists())
		{
		String[]entries = index.list();
		for(String s: entries){
		    File currentFile = new File(index.getPath(),s);
		   if(String.valueOf(currentFile.getAbsolutePath()).contains("part"))
		   {
			   if(!String.valueOf(currentFile.getAbsolutePath()).contains("crc"))
		   {
			   	   
			   
			   reader = new BufferedReader(new FileReader(currentFile.getAbsolutePath()));
				 while ((s1=reader.readLine())!= null ) {
					  jo = (JSONObject) jp.parse(s1);
					  String s2=(String) jo.get("name");
					  Long d1 = (Long) jo.get("total"); 
					  dataset.setValue(s2,d1);
				  //   out.append( line );
				  }  }}
		   }
		}
		
		}
		else if (currenttitle.contentEquals("Tweets Volume By Date"))
		{
			File index = new File("/home/shankar/Desktop/trends_task2/volumebydate");
			if (index.exists())
			{
			String[]entries = index.list();
			for(String s: entries){
			    File currentFile = new File(index.getPath(),s);
			   if(String.valueOf(currentFile.getAbsolutePath()).contains("part"))
			   {
				   if(!String.valueOf(currentFile.getAbsolutePath()).contains("crc"))
			   {
				   	   
				   
				   reader = new BufferedReader(new FileReader(currentFile.getAbsolutePath()));
					 while ((s1=reader.readLine())!= null ) {
						  jo = (JSONObject) jp.parse(s1);
						  String s2=(String) jo.get("date");
						  Long d1 = (Long) jo.get("volume"); 
						  dataset.setValue(s2,d1);
					  //   out.append( line );
					  }  }}
			   }
			}
		}
		///////
		else if (currenttitle.contentEquals("http://www.careerarc.com/job-seeker"))
		{
			File index = new File("/home/shankar/Desktop/Task3/CareerJobs");
			if (index.exists())
			{
			String[]entries = index.list();
			for(String s: entries){
			    File currentFile = new File(index.getPath(),s);
			   if(String.valueOf(currentFile.getAbsolutePath()).contains("part"))
			   {
				   if(!String.valueOf(currentFile.getAbsolutePath()).contains("crc"))
			   {
				   	   
				   
				   reader = new BufferedReader(new FileReader(currentFile.getAbsolutePath()));
					 while ((s1=reader.readLine())!= null ) {
						  jo = (JSONObject) jp.parse(s1);
						  String s2=(String) jo.get("name");
						  Long d1 = (Long) jo.get("frequency"); 
						  dataset.setValue(s2,d1);
					  //   out.append( line );
					  }  }}
			   }
			}
		}
		else if (currenttitle.contentEquals("Jobs With Maximum Engagement"))
		{
			File index = new File("/home/shankar/Desktop/Task3/TrendingLinks");
			if (index.exists())
			{
			String[]entries = index.list();
			for(String s: entries){
			    File currentFile = new File(index.getPath(),s);
			   if(String.valueOf(currentFile.getAbsolutePath()).contains("part"))
			   {
				   if(!String.valueOf(currentFile.getAbsolutePath()).contains("crc"))
			   {
				   	   
				   
				   reader = new BufferedReader(new FileReader(currentFile.getAbsolutePath()));
					 while ((s1=reader.readLine())!= null ) {
						  jo = (JSONObject) jp.parse(s1);
						  String s2=(String) jo.get("url");
						  Long d1 = (Long) jo.get("frequency"); 
						  dataset.setValue(s2,d1);
					  //   out.append( line );
					  }  }}
			   }
			}
		}
		
	} catch (FileNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (ParseException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}          
      
      
     /* dataset.setValue( "IPhone 5s" , new Double( 20 ) );  
      dataset.setValue( "SamSung Grand" , new Double( 20 ) );   
      dataset.setValue( "MotoG" , new Double( 40 ) );    
      dataset.setValue( "Nokia Lumia" , new Double( 10 ) );  */
      return dataset;         
   }
   
   private static JFreeChart createChart( PieDataset dataset ) {
	   JFreeChart chart = null;
	   if((currenttitle.contentEquals("Trending Hash Tags")))
			   {
       chart = ChartFactory.createPieChart3D(      
         currenttitle,   // chart title 
         dataset,          // data    
         true,             // include legend   
         true, 
         false);
			   }
	   else if(currenttitle.contentEquals("Tweets Volume By Date"))
	   {
		   chart = ChartFactory.createPieChart3D(      
			         currenttitle,   // chart title 
			         dataset,          // data    
			         true,             // include legend   
			         true, 
			         false);
	   }
	   else if (currenttitle.contentEquals("http://www.careerarc.com/job-seeker"))
	   {
		   chart = ChartFactory.createPieChart3D(      
			         currenttitle,   // chart title 
			         dataset,          // data    
			         true,             // include legend   
			         true, 
			         false); 
	   }
	   else if (currenttitle.contentEquals("Jobs With Maximum Engagement"))
	   {
		   chart = ChartFactory.createPieChart3D(      
			         currenttitle,   // chart title 
			         dataset,          // data    
			         true,             // include legend   
			         true, 
			         false); 
	   }
      return chart;
   }
   
   public static JPanel createDemoPanel( ) {
      JFreeChart chart = createChart(createDataset( ) );  
      return new ChartPanel( chart ); 
   }

   public static void main( String args1,String args2 ) {
	   if (args1.contentEquals("Task2"))
	   {
	   currenttitle= "Trending Hash Tags";
      PieChart_AWT demo = new PieChart_AWT(currenttitle); 
      demo.setSize( 720 , 467 );    
      RefineryUtilities.centerFrameOnScreen( demo );    
      demo.setVisible( true );
      currenttitle= "Tweets Volume By Date";
       demo = new PieChart_AWT(currenttitle);  
      demo.setSize(670 , 467 );    
      RefineryUtilities.centerFrameOnScreen( demo );    
      demo.setVisible( true );
	   }
	   
	   if(args1.contentEquals("Task3"))
	   {
		   if(args2.contentEquals("CareerJobs"))
		   {
		    currenttitle= "http://www.careerarc.com/job-seeker";
		      PieChart_AWT demo = new PieChart_AWT(currenttitle); 
		      demo.setSize( 720 , 467 );    
		      RefineryUtilities.centerFrameOnScreen( demo );    
		      demo.setVisible( true );
		   }
		   else if (args2.contentEquals("TrendingJobs"))
		   {
			   currenttitle= "Jobs With Maximum Engagement";
			      PieChart_AWT demo = new PieChart_AWT(currenttitle); 
			      demo.setSize( 720 , 467 );    
			      RefineryUtilities.centerFrameOnScreen( demo );    
			      demo.setVisible( true );  
		   }
	   }
      
   }}
