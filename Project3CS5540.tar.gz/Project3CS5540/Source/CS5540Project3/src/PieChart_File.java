
import java.io.*; 

import java.util.StringTokenizer; 

import org.jfree.chart.ChartUtilities; 
import org.jfree.chart.ChartFactory; 
import org.jfree.chart.JFreeChart; 
import org.jfree.data.general.DefaultPieDataset;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

public class PieChart_File {
   
   public static void main( String[ ] args )throws Exception {
      
      /*String mobilebrands[ ] = {    
         "IPhone 5s" ,   
         "SamSung Grand" ,   
         "MotoG" ,    
         "Nokia Lumia" 
      };*/
	   String s1="";
	   JSONObject jo;
      
      InputStream in = new FileInputStream( new File( "/home/shankar/Desktop/datajson/part-00000-b93f0626-1d66-4e37-b6ca-7b3d674d3f25.json") );          
      BufferedReader reader = new BufferedReader(new InputStreamReader(in ));
      JSONParser jp = new JSONParser();          
      DefaultPieDataset dataset = new DefaultPieDataset();          
      while ((s1=reader.readLine())!= null ) {
    	  jo = (JSONObject) jp.parse(s1);
    	  String s2=(String) jo.get("name");
    	  Double d1 = (Double) jo.get("count(1)"); 
    	  dataset.setValue(s2,d1);
      //   out.append( line );
      }
      
      
      
      JFreeChart chart = ChartFactory.createPieChart( 
         "Trending Websites",    // chart title           
         dataset,           // data           
         true,              // include legend           
         true,           
         false);
      
      int width = 560;    /* Width of the image */          
      int height = 370;   /* Height of the image */                          
      File pieChart = new File( "pie_Chart.jpeg" );                        
      ChartUtilities.saveChartAsJPEG( pieChart, chart, width, height); 
   }
}
