import java.io.File;

import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.sql.functions;

//import org.apache.spark.sql.functions.*;
public class task2 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SparkSession spark = SparkSession
				  .builder()
				  .appName("Spark SQL basic example").master("local")
				  .config("spark.some.config.option", "some-value")
				  .getOrCreate();
		Dataset<Row> df = spark.read().json("/home/shankar/Desktop/trends.txt");
		Dataset<Row> de = df.select(org.apache.spark.sql.functions.explode(df.col("details")));
		Dataset<Row> de2=de.select(org.apache.spark.sql.functions.explode(de.col("col.trends")),de.col("col.created_at"));
		Dataset<Row> de3 = de2.select(de2.col("created_at"),de2.col("col.name"),de2.col("col.tweet_volume"));
		//de3.registerTempTable("table1");
		de3.createOrReplaceTempView("table1");
		Dataset<Row> result1 = spark.sql("select name,sum(tweet_volume) as total,count(*) as frequency from table1 group by name order by count(1) desc LIMIT 10");
		//Delete File if exists
		File index = new File("/home/shankar/Desktop/trends_task2/hashtags");
		if (index.exists())
		{
		String[]entries = index.list();
		for(String s: entries){
		    File currentFile = new File(index.getPath(),s);
		    currentFile.delete();
		}
		 index.delete();
		}
		//Top 10 Trending hashtags and their tweets volume from the whole trends file
		result1.coalesce(1).write().json("/home/shankar/Desktop/trends_task2/hashtags");
		
		Dataset<Row> result2 = spark.sql("select substring(created_at,1,10) as date,sum(tweet_volume) as volume from table1 group by substring(created_at,1,10) order by substring(created_at,1,10)");
		
		
		//Delete File if exists
		index = new File("/home/shankar/Desktop/trends_task2/volumebydate");
		if (index.exists())
		{
		String[]entries = index.list();
		for(String s: entries){
		    File currentFile = new File(index.getPath(),s);
		    currentFile.delete();
		}
		 index.delete();
		}
		
		//Tweets volume per day 
		result2.coalesce(1).write().json("/home/shankar/Desktop/trends_task2/volumebydate");
		
		
		
	/*	Dataset<Row> dt=de.groupBy(org.apache.spark.sql.functions.substring(de.col("col.created_at"),1,10).as("date")).count().orderBy(de.col("date"));
		
		//count of tweets by date
		de.write().mode("append").json("/home/shankar/Desktop/tweetsinp");
		
		Dataset<Row> trends = df.select(org.apache.spark.sql.functions.explode(df.col("details.trends")).as("trendscol"));
		Dataset<Row> inner = trends.select(org.apache.spark.sql.functions.explode(trends.col("trendscol")	).as("content"));
		Dataset<Row> counttext=inner.groupBy("content.name").count();
		Dataset<Row> top10tags = counttext.select("name","count").orderBy(org.apache.spark.sql.functions.col("count").desc()).limit(10);
		//Dataset<Row> sumhashtags =counttext.agg(org.apache.spark.sql.functions.col("count"));
		
		
		//sumhashtags.write().format("com.databricks.spark.csv").option("header", "true").save("/home/shankar/Desktop/java1");
        
		top10tags.write().format("com.databricks.spark.csv")
        .option("header", "true")
        .save("/home/shankar/Desktop/java2"); */
		
		System.out.println("Task2 Succesfully Completed");
		
		PieChart_AWT.main("Task2","NA");
		
		System.out.println("Piechart Main method invoked for task2");
	}

}
