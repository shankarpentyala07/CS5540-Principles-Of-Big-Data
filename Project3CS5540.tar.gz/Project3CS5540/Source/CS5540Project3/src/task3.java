import java.io.File;

import org.apache.spark.sql.SparkSession;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.functions.*;
import static org.apache.spark.sql.functions.col;
public class task3 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SparkSession spark = SparkSession
				  .builder()
				  .appName("Spark SQL basic example").master("local")
				  .config("spark.some.config.option", "some-value")
				  .getOrCreate();
		Dataset<Row> df = spark.read().json("/home/shankar/Desktop/jobtag.txt");
		df.createOrReplaceTempView("table1");
		Dataset<Row> sqlDF = spark.sql("select user.url,count(*) as frequency from table1 where user.url is not null GROUP BY user.url order by count(1) desc LIMIT 10");
		sqlDF.show();
		sqlDF.printSchema();
		//Delete File if exists
				File index = new File("/home/shankar/Desktop/Task3/TrendingLinks");
				if (index.exists())
				{
				String[]entries = index.list();
				for(String s: entries){
				    File currentFile = new File(index.getPath(),s);
				    currentFile.delete();
				}
				 index.delete();
				}
		//Most frequently posted top 10 Url's regarding Jobs		
	    sqlDF.coalesce(1).write().mode("append").json("/home/shankar/Desktop/Task3/TrendingLinks");
	    
	    Dataset<Row> sqlDF1 =spark.sql("select user.name,user.url,count(*) as frequency from table1 where user.url is not null GROUP BY user.name,user.url order by count(1) desc LIMIT 10");
	   //Delete File if exists
		index = new File("/home/shankar/Desktop/Task3/JobType");
		if (index.exists())
		{
		String[]entries = index.list();
		for(String s: entries){
		    File currentFile = new File(index.getPath(),s);
		    currentFile.delete();
		}
		 index.delete();
		}
       //Type of Jobs provided by these frequent URL's		
       sqlDF1.coalesce(1).write().mode("append").json("/home/shankar/Desktop/Task3/JobType");
       
       
      //Career Url is providing many types of jobs ,below are top 10 it provides
      Dataset<Row> sqlDF2= spark.sql("select user.name,user.url,count(*) as frequency from table1 where user.url ='http://www.careerarc.com/job-seeker' group by user.name,user.url order by count(1) desc LIMIT 10");
     //Delete File if exists
     		index = new File("/home/shankar/Desktop/Task3/CareerJobs");
     		if (index.exists())
     		{
     		String[]entries = index.list();
     		for(String s: entries){
     		    File currentFile = new File(index.getPath(),s);
     		    currentFile.delete();
     		}
     		 index.delete();
     		}
            //Type of Jobs provided by these frequent URL's		
            sqlDF2.coalesce(1).write().mode("append").json("/home/shankar/Desktop/Task3/CareerJobs");
            
      //Most followed Jobs
            Dataset<Row> sqlDF3 =spark.sql("select user.name,user.url,user.followers_count from table1 order by user.followers_count desc LIMIT 10");
            index = new File("/home/shankar/Desktop/Task3/DemandJobs");
     		if (index.exists())
     		{
     		String[]entries = index.list();
     		for(String s: entries){
     		    File currentFile = new File(index.getPath(),s);
     		    currentFile.delete();
     		}
     		 index.delete();
     		}
            //Most followed and jobs in demand	
            sqlDF3.coalesce(1).write().mode("append").json("/home/shankar/Desktop/Task3/DemandJobs");
            
            System.out.println("Preparing Pie Chart for Career Jobs of Task 3");
            PieChart_AWT.main("Task3","CareerJobs");
            
            System.out.println("Preparing Pie Chart for Trending Jobs of Task 3");
            PieChart_AWT.main("Task3","TrendingJobs");
            
            System.out.println("Preparing Bar Chart for Demand Jobs of Task 3");
            Bar_Chart_AWT.main("Task3","DemandJobs");
            
            System.out.println("Preparing Bar Chart for Trending Job Types of Task 3");
            Bar_Chart_AWT.main("Task3","JobType");
       
       
       //sqlDF.coalesce(1)
		  // .write().format("com.databricks.spark.csv")
		   //.option("header", "true")
		   //.save("/home/shankar/Desktop/data");
		System.out.println("Task3 Succesfully Completed");
	}

}
