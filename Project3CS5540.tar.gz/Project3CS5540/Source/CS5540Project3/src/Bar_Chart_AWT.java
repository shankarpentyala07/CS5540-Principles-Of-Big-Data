import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel; 
import org.jfree.chart.JFreeChart; 
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.category.CategoryDataset; 
import org.jfree.data.category.DefaultCategoryDataset; 
import org.jfree.ui.ApplicationFrame; 
import org.jfree.ui.RefineryUtilities; 
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

public class Bar_Chart_AWT extends ApplicationFrame {
	static String Currenttask;
   
   public Bar_Chart_AWT( String applicationTitle , String chartTitle ) {
      super( applicationTitle );        
      JFreeChart barChart = ChartFactory.createBarChart3D(
         chartTitle,           
         "Category",            
         "Score",            
         createDataset(),          
         PlotOrientation.VERTICAL,           
         true, true, false);
         
      ChartPanel chartPanel = new ChartPanel( barChart );        
      chartPanel.setPreferredSize(new java.awt.Dimension( 660 , 467 ) );        
      setContentPane( chartPanel ); 
   }
   
   private CategoryDataset createDataset( ) {
            
      final String speed = "TrendingUrls";        
             
      final DefaultCategoryDataset dataset = 
      new DefaultCategoryDataset( );  
      InputStream in;
      BufferedReader reader;
      JSONParser jp = new JSONParser();
      String s1;
      JSONObject jo;
      if(Currenttask.contentEquals("DemandJobs"))
    		  {
      File index = new File("/home/shankar/Desktop/Task3/DemandJobs");
		if (index.exists())
		{
		String[]entries = index.list();
		for(String s: entries){
		    File currentFile = new File(index.getPath(),s);
		   if(String.valueOf(currentFile.getAbsolutePath()).contains("part"))
		   {
			   if(!String.valueOf(currentFile.getAbsolutePath()).contains("crc"))
		   {
			   	   
			   
			   try {
				reader = new BufferedReader(new FileReader(currentFile.getAbsolutePath()));
				try {
					while ((s1=reader.readLine())!= null ) {
						  jo = (JSONObject) jp.parse(s1);
						  String s2="Jobs In Demand";
						  String s3=(String) jo.get("name");
						  Long d1 = (Long) jo.get("followers_count"); 
						  dataset.addValue(d1,s3,s2);
					  //   out.append( line );
					  }
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (ParseException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
				   }}
		   }
		}
		
        }
      else if(Currenttask.contentEquals("JobType"))
	  {
File index = new File("/home/shankar/Desktop/Task3/JobType");
if (index.exists())
{
String[]entries = index.list();
for(String s: entries){
    File currentFile = new File(index.getPath(),s);
   if(String.valueOf(currentFile.getAbsolutePath()).contains("part"))
   {
	   if(!String.valueOf(currentFile.getAbsolutePath()).contains("crc"))
   {
	   	   
	   
	   try {
		reader = new BufferedReader(new FileReader(currentFile.getAbsolutePath()));
		try {
			while ((s1=reader.readLine())!= null ) {
				  jo = (JSONObject) jp.parse(s1);
				  String s2=(String) jo.get("url");
				  String s3=(String) jo.get("name");
				  s2= s2 + "/" +"Type: " + s3;
				  
				  Long d1 = (Long) jo.get("frequency"); 
				  dataset.addValue(d1,s2,s3);
			  //   out.append( line );
			  }
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	} catch (FileNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
		   }}
   }
}

}

  
      return dataset; 
   }
   
   public static void main( String args1,String args2 ) {
	   if (args1.contentEquals("Task3"))
	   {
		   if(args2.contentEquals("DemandJobs"))
		   {
			   Currenttask ="DemandJobs";
      Bar_Chart_AWT chart = new Bar_Chart_AWT("Most Valued Jobs", 
         "Which Jobs are in demand?");
      chart.pack( );        
      RefineryUtilities.centerFrameOnScreen( chart );        
      chart.setVisible( true );
		   }
		   else if(args2.contentEquals("JobType"))
		   {
			   Currenttask ="JobType";
      Bar_Chart_AWT chart = new Bar_Chart_AWT("Most Valued Job Types", 
         "Which JobTypes are in demand?");
      chart.pack( );        
      RefineryUtilities.centerFrameOnScreen( chart );        
      chart.setVisible( true );
		   }
	   }
	   
   }
}