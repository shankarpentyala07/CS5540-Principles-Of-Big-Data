import java.util.Arrays;
import java.util.Iterator;

import org.apache.hadoop.record.Record;
import org.apache.spark.SparkConf;
import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.api.java.function.FlatMapFunction;
import org.apache.spark.api.java.function.Function;
import org.apache.spark.api.java.function.Function2;
import org.apache.spark.api.java.function.PairFunction;
import org.apache.spark.rdd.RDD;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.SparkSession;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

import scala.Enumeration.Val;
import scala.Tuple2;

public class task1
{
	public static void main(String args[])
	{
		SparkConf conf = new SparkConf().setMaster("local").setAppName("Work Count App");

        // Create a Java version of the Spark Context from the configuration
        JavaSparkContext sc = new JavaSparkContext(conf);

        // Load the input data, which is a text file read from the command line
        JavaRDD<String> data = sc.textFile("/home/shankar/Desktop/jobtag.txt");
        JSONParser jp = new JSONParser();
        String s1;
        JSONObject jo;
        
        JavaRDD<Record> rdd_records = sc.textFile(data).map(
        		  new Function<String, Record>() {
        		      public Record call(String line) throws Exception {
        		         // Here you can use JSON
        		         // Gson gson = new Gson();
        		         // gson.fromJson(line, Record.class);
        		         String[] fields = line.split(",");
        		         Record sd = new Record(fields[0], fields[1], fields[2].trim(), fields[3]);
        		         return sd;
        		      }});
        
        JavaRDD<Record> rdd_records=sc.textfile.flatMap(x=>(x.split(",\""))) .filter(line=>line.contains("location"))
        		  .flatMap(x=>(x.split("location\":"))) .filter(x => x!="null").filter(x => x!="")
        		  .filter(line=>line.contains(",")) .map(temp => (temp,1)) .reduceByKey(_+_) .sortBy(_._2,false)
        		  .take(10) .foreach(println
        rddrecords.saveAsTextFile("/home/shankar/Desktop/task1");
    
	
     
	}
}
