/*  ****************************************************************************************************************************************
Course : CS5540 Spring 2017

Instructor : Anas Katib.

Program Creation Date : March5th 2018

Programmers:
1.Girish Kumar Reddy Nagella 
2.Vamsy Krishna Challa
3.Sindhu
4.Shankar Pentyala

Team No : 18

This program takes a text input file containing tweets and creates the directories/filenames with the top 10 HashTags and tweets with other 
HashTags and tweets with No Hashtags in the Local System and then creates a copy of those in HDFS.
********************************************************************************************************************************************* */
//Import all the required Packages.
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.Map;
import java.util.Map.Entry;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;


public class CS5540Project1 {

	/**
	 * @param args
	 * @throws IOException 
	 * @throws URISyntaxException 
	 */
	public static void main(String[] args) throws IOException, URISyntaxException {
		// TODO Auto-generated method stub
		Map<String,Integer> map1 = new HashMap<String,Integer>();
		String text1="";
		String s1="";
		JSONObject jo;
		JSONObject jo1;
		JSONArray ja1;
		JSONObject temp;
		Integer exists;
		JSONParser jp;
		FileReader fr = null;
		BufferedReader br = null;
		
		//Extract all the HashTags in the input tweets file and store them in a map.
		
		try {
			fr = new FileReader("//home//shankar//Desktop//twitter_stream_1tweets.txt");
			br = new BufferedReader(fr);
			jp = new JSONParser();
			
			try {
				while((s1 =br.readLine())!=null)
				{
			   try {
				jo = (JSONObject) jp.parse(s1);
				 jo1=(JSONObject) jo.get("entities");
				ja1 = (JSONArray) jo1.get("hashtags");
				for(int i=0;i<ja1.size();i++)
				{
			       temp = (JSONObject) ja1.get(i);
			       text1 = (String) temp.get("text");
			       exists = map1.get(text1);
			       if(exists == null)
			       {
			    	   map1.put(text1,1);
			       }
			       else
			       {
			    	   map1.put(text1,exists+1);
			       }
				}
				
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			   
				}
				System.out.println(map1);
				
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			br.close();
		} catch (IOException e2) {
			// TODO Auto-generated catch block
			e2.printStackTrace();
		}
		try {
			fr.close();
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		
		//Sort the map in the descending order of the values
		
		LinkedList<Entry<String, Integer>> list =
	            new LinkedList<Map.Entry<String,Integer>>( map1.entrySet() );
	        Collections.sort( list, new Comparator<Map.Entry<String,Integer>>()
	        {
	            public int compare( Map.Entry<String,Integer> o2, Map.Entry<String,Integer> o1 )
	            {
	                return (o1.getValue()).compareTo( o2.getValue() );
	            }
	        } );
	        
	       
	        LinkedHashMap<String,Integer> Map2 = new LinkedHashMap<String,Integer>();
	        System.out.println(list);
	        int count = 0;
	        String tempfilename="";
	        String tempfilename1="";
	        PrintWriter writer;
	        File f1;
	        
	        /* Finding top 10 hash tags and creating files in the local system for top 10 hashtags and file for No Hash tags
	         and a file for tweets with other hash tags  */
	        
	        for(Map.Entry<String,Integer> m2 : list)
	        {
	        	count++;
	        	Map2.put( m2.getKey(), m2.getValue() );
	        	 tempfilename = m2.getKey();
	        	 tempfilename1= "//home//shankar//Desktop//"+tempfilename+".txt";
	        	 System.out.println(tempfilename1);
	        	 f1 = new File(tempfilename1);
	        	if(!f1.exists())
	        	{
	        		try {
						f1.createNewFile();
						
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
	        	}
	        	else
	        	{
	        		writer = new PrintWriter(f1);
	        		writer.print("");
	        		writer.close();
	        	}
	        	if (count == 10)
	        	{
	        		break;
	        	}
	        	
	        }
	        //Creation of file with other hash tags
	        f1 = new File("//home//shankar//Desktop//Othertweets.txt");
	        if (!f1.exists())
	        {
	        	try {
					f1.createNewFile();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
	        }
	        else
	        {
	        	writer = new PrintWriter(f1);
        		writer.print("");
        		writer.close();	
	        }
	        
	        
	        //File for No hash tags tweets 
	        
	        f1 = new File("//home//shankar//Desktop//NoHashtagtweets.txt");
	        if (!f1.exists())
	        {
	        	try {
					f1.createNewFile();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
	        }
	        else
	        {
	        	writer = new PrintWriter(f1);
        		writer.print("");
        		writer.close();	
	        }
	        System.out.println(Map2);
	        
	        
	        
	        /* Reading input file and organizing the tweets to respective folders */
	        
	        File filetemp;
	        FileReader fr2;
	        BufferedReader br2;
	        JSONObject jobj = null;
	        try {
				fr2 = new FileReader("//home//shankar//Desktop//twitter_stream_1tweets.txt");
				br2 = new BufferedReader(fr2);
				JSONParser jp1 = new JSONParser();
				try {
					while((s1=br2.readLine())!= null)
					{
						jobj = (JSONObject) jp1.parse(s1);
					    jo1 = (JSONObject) jobj.get("entities");
					    ja1 = (JSONArray) jo1.get("hashtags");
					    if (ja1.size() > 0)
					    {
					    	for(int i =0;i<ja1.size();i++)
							{
								temp = (JSONObject) ja1.get(i);
								text1 = (String) temp.get("text");
								exists = Map2.get(text1);
								//Map2.containsKey()
								if(!(exists == null))
								{
								 filetemp =new File("/home/shankar/Desktop/"+text1+".txt");
								 if(!filetemp.exists())
								 {
									 filetemp.createNewFile();
								 }
								FileWriter fww = new FileWriter(filetemp,true);
								BufferedWriter bww = new BufferedWriter(fww);
								bww.write(s1);
								bww.write('\n');
								bww.flush();
								}
								else
								{
									filetemp=new File("/home/shankar/Desktop/Othertweets.txt");
									if(!filetemp.exists())
									{
										filetemp.createNewFile();
									}
									FileWriter fww1 = new FileWriter(filetemp,true);
									BufferedWriter bww1 = new BufferedWriter(fww1);
									bww1.write(s1);
									bww1.write('\n');
									bww1.flush();
								}
								}
					    }
					    else
					    {
					    	File filetemp1=new File("/home/shankar/Desktop/NoHashtagtweets.txt");
							if(!filetemp1.exists())
							{
								filetemp1.createNewFile();
							}
							FileWriter fww2 = new FileWriter(filetemp1,true);
							BufferedWriter bww2 = new BufferedWriter(fww2);
							bww2.write(s1);
							bww2.write('\n');
							bww2.flush();
					    	
					    }}
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (ParseException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			

	        //Copies Local files to HDFS System
	        
	        Configuration conf =new Configuration();
	        String hdfs1 ="hdfs://localhost:9000";
			URI a= new URI(hdfs1);;
			FileSystem fs = FileSystem.get(a,conf);
			Path destfile;
			Path srcfile;
			String tempfilename2;
			
			System.out.println("Connecting to HDFS System");
			
			
			
	         
	       // Copy Top 10 Hash Tags file
			count = 0;
	        for(Map.Entry<String,Integer> m2 : list)
	        {
	        	count++;
	        	Map2.put( m2.getKey(), m2.getValue() );
	        	
	       	     tempfilename = m2.getKey();
	        	 tempfilename1= "/user/"+tempfilename+"/"+tempfilename+".txt";
	        	 tempfilename2 ="/home/shankar/Desktop/"+tempfilename+".txt";
	        	 srcfile = new Path(tempfilename2);
	        	 destfile = new Path(tempfilename1);
	        	 if(!fs.exists(destfile))
	        	 {
	        		 fs.createNewFile(destfile);
	        		 
	        	 }
	        	 fs.copyFromLocalFile(srcfile,destfile);
	        	 
	        	if (count == 10)
	        	{
	        		break;
	        	}
	        	
	        }
	        
	        //Copy Other Hash tags file
	        
	        srcfile = new Path("/home/shankar/Desktop/Othertweets.txt");
       	      destfile = new Path("/user/Othertweets/Othertweets.txt");
	       
	        if (!fs.exists(destfile))
	        {
	        	fs.createNewFile(destfile);
	        	
	        	
	        }
	        fs.copyFromLocalFile(srcfile,destfile);
	        
	        //Copy No Hash Tags File
	        
	        srcfile = new Path("/home/shankar/Desktop/NoHashtagtweets.txt");
     	      destfile = new Path("/user/NoHashtagtweets/NoHashtagtweets.txt");
	       
	        if (!fs.exists(destfile))
	        {
	        	fs.createNewFile(destfile);
	        	
	        	
	        }
	        fs.copyFromLocalFile(srcfile,destfile);
	        
	        System.out.println("Copied Successfully");
	        
	}

}
