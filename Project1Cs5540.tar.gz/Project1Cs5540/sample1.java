/*  ****************************************************************************************************************************************
Course : CS5540 Spring 2017

Instructor : Anas Katib.

Program Creation Date : March5th 2018

Programmers:
1.Girish Kumar Reddy Nagella 
2.Vamsy Krishna Challa
3.Sindhu
4.Shankar Pentyala

Team No : 18

counts the number of times a key word appears in one of two tweet JSON attributes (text and hashtags) in all of 12 directories that were 
created on HDFS

Input Parameters - Search Keyword
Input Attribute - HASHTAG or TEXT

********************************************************************************************************************************************* */
//Import the necessary Packages 

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.Scanner;
import java.util.StringTokenizer;

//import org.apache.commons.io.IOUtils;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FSDataInputStream;
import org.apache.hadoop.fs.FileStatus;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.FileUtil;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IOUtils;
import org.apache.hadoop.util.Progressable;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;


public class sample1 {

	
	public static void main(String[] args) throws IOException, URISyntaxException, ParseException {
		
		//Get Keyword,Attribute from the user.
		Scanner inpconsole = new Scanner(System.in);
		System.out.println("Enter Keyword to find");
		String Search_Keyword = inpconsole.next();
		System.out.println("Enter Attribute to search");
		String Search_attr = inpconsole.next();
		
		//Connection to HDFS 

		    Configuration conf =new Configuration();
		    String [] filenames =new String[12];
			String s1 ="hdfs://localhost:9000";
			URI a= new URI(s1);;
			FileSystem fs = FileSystem.get(a,conf);
			Path file = new Path("hdfs://localhost:9000/user/");
			FileStatus[] filestatus = fs.listStatus(file);
			Path[] paths = FileUtil.stat2Paths(filestatus);
			
			
			//Get  the List of the directories
			int i=0;
			for(Path path : paths)
		    {
		      filenames[i]=path.toString();
		      
		      i++;
		    }
			
			
			
			//Get the List of files under these directories
			
			String [] filenames1 =new String[12];
			int k =0;
			for(int j=0;j<filenames.length;j++)
			{
				file = new Path(filenames[j]);
				filestatus = fs.listStatus(file);
				paths =FileUtil.stat2Paths(filestatus);
				for(Path path : paths)
			    {
			      filenames1[k]=path.toString();
			      k++;
			      
			    }
			}
			
			Path filepath;
			BufferedReader br=null;
			String inp;
			JSONObject jo1;
			JSONObject jo;
			JSONArray ja1;
			JSONObject temp;
			String text1;
			JSONParser jp = new JSONParser();
			int hashcount = 0;
			
			//Finds the frequency of the hash tag input by user
			if(Search_attr.equals("HASHTAG"))
			{
			for(int k1= 0;k1<12;k1++)
			{
				filepath =new Path(filenames1[k1]);
				br=new BufferedReader(new InputStreamReader(fs.open(filepath)));
				while((inp=br.readLine())!=null)
	            	
	            {
	            	jo = (JSONObject) jp.parse(inp);
	            	jo1=(JSONObject) jo.get("entities");
					ja1 = (JSONArray) jo1.get("hashtags");
					for(int tempvar=0;tempvar<ja1.size();tempvar++)
					{
				       temp = (JSONObject) ja1.get(tempvar);
				       text1 = (String) temp.get("text");
	            	   if(text1.equals(Search_Keyword))
	            	   {
	            		   hashcount++;
	            	   }
	            	}
					}
	
			}
			System.out.println(Search_Keyword +" - Count:" + hashcount);
            System.out.println("successful");
			}
			
			//Finds the frequency of the text input by user
			
			int textcount = 0;
			StringTokenizer st ;
			if(Search_attr.equals("TEXT"))
			{
				for(int k1= 0;k1<12;k1++)
				{
					filepath =new Path(filenames1[k1]);
					br=new BufferedReader(new InputStreamReader(fs.open(filepath)));
					while((inp=br.readLine())!=null)
		            	
		            {
		            	jo = (JSONObject) jp.parse(inp);
		            	text1 =(String) jo.get("text");
		            	st= new StringTokenizer(text1);
		            	  while(st.hasMoreTokens())
		            	  {
		            	   if(st.nextToken().equals(Search_Keyword))
		            	   {
		            		   textcount++;
		            	   }
		            	  }
		            	
						}
		
				}
				System.out.println(Search_Keyword + " " +Search_attr+" - Count:" + textcount);
	            System.out.println("successful");
	            
			}
		
	}

}
