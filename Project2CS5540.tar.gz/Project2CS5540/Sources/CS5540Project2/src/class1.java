
import java.io.BufferedWriter;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.net.URI;
import java.util.*;

import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.conf.*;
import org.apache.hadoop.io.*;
import org.apache.hadoop.mapred.*;
import org.apache.hadoop.util.*;
import org.json.JSONException;
import org.json.JSONObject;
    
public class class1 {
	    static int uniquewords=0;
	    static int duplicatewords=0;
	public static class Map extends MapReduceBase implements Mapper<LongWritable, Text, Text, IntWritable> {
		JSONObject object=null;
		String str=null;
		private final static IntWritable one = new IntWritable(1);
        private Text wordfrommap = new Text();

	public void map(LongWritable key, Text value, OutputCollector<Text, IntWritable> output, Reporter reporter) throws IOException {
        String line = value.toString();	 
		try {
			object = new JSONObject(line);
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		 if(object.has("text")){
		
		try {
			str = object.getString("text");
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		 StringTokenizer tokenizer = new StringTokenizer(str);
		 while (tokenizer.hasMoreTokens()) {
	     wordfrommap.set(tokenizer.nextToken().toUpperCase().replaceAll("\\W",""));
	     output.collect(wordfrommap, one);
		}
		  }
	 }
	}
	 public static class Reduce extends MapReduceBase implements Reducer<Text, IntWritable, Text, IntWritable> {
		 public void reduce(Text key, Iterator<IntWritable> values, OutputCollector<Text, IntWritable> output, Reporter reporter) throws IOException {
		    int count = 0;
		  while (values.hasNext()) {
		   count += values.next().get();
	 }
		  if(count ==1)
		  {
		 output.collect(key, new IntWritable(count));
		FileWriter fw= new FileWriter("/home/shankar/Desktop/uniqueWords.txt",true);
			BufferedWriter bw=new BufferedWriter(fw);
	         bw.write(key+"   "+count +"\n");
	         bw.flush();
	         bw.close();
	         uniquewords++;
		 }
		  else
		  {
			  output.collect(key, new IntWritable(count));
				FileWriter fw= new FileWriter("/home/shankar/Desktop/DuplicateWords.txt",true);
					BufferedWriter bw=new BufferedWriter(fw);
			         bw.write(key+"   "+count +"\n");
			         bw.flush();
			         bw.close();
			         duplicatewords++; 
		  }
		 }
	     
		  }
	 
	 public static void main(String[] args) throws Exception {
		 URI url=new URI("hdfs://localhost:9000"); 
	     Configuration con = new Configuration();
         FileSystem f=FileSystem.get(url,con);
         JobConf conf = new JobConf(class1.class);
         conf.setJobName("wordcount");

         conf.setOutputKeyClass(Text.class);
         conf.setOutputValueClass(IntWritable.class);

         conf.setMapperClass(Map.class);
         conf.setCombinerClass(Reduce.class);
         conf.setReducerClass(Reduce.class);

         conf.setInputFormat(TextInputFormat.class);
         conf.setOutputFormat(TextOutputFormat.class);
	     FileInputFormat.setInputPaths(conf,f.makeQualified(new Path("/CS5540Project2/inpfile.txt")));
         FileOutputFormat.setOutputPath(conf, f.makeQualified(new Path("/CS5540Project2/Output")));

         JobClient.runJob(conf);
         System.out.println("Unique Words Count is :"+uniquewords);
         System.out.println("Duplicate words count is :"+duplicatewords);
         System.out.println("Ratio of unique words to duplicate words is :"+ ((float)duplicatewords / uniquewords));
   
 }
}